#!/usr/bin/env pythonw
#
# Python 2&3 code to check we are a legit Opendime.
#
from __future__ import print_function
try:
    input = raw_input
    B2A = lambda x:x
except NameError:
    # Py3
    B2A = lambda x: str(x, 'ascii')
import os, sys
from . import remote_pycoin
from pycoin.key import msg_signing as MS
from collections import OrderedDict
from .shared import find_root

def fail(msg):
    print("\n" + '*'*48)
    print("FAIL FAIL FAIL -- Do Not Trust -- FAIL FAIL FAIL")
    print('*'*48 + '\n')

    print('PROBLEM: ' + msg)
    sys.exit(1)

def lowlevel_tests(path, expect_addr, version):
    # this requires: "pip install PyUSB" and a working libusb library
    try:
        import usb, usb.core
    except ImportError:
        print("\n(additional tests are possible with libusb and PyUSB installed)\n")
        return

    import json, string, random, time
    from base64 import b64encode

    print("\nAdditional low-level checks:")

    if hasattr(os, 'statvfs'):
        g = os.statvfs(path)
        try:
            assert g.f_bsize == 131072
            assert g.f_frsize == 512
            assert g.f_blocks in (2847, 2880)
        except AssertionError:
            fail("os.statvfs didn't shown correct disk geometry")
        print("  - correct virtual disk geometry")

    expect = json.load(open(os.path.join(path, 'advanced', 'variables.json')))

    class dev(object):
        def __init__(self, sn):
            self.dev = usb.core.find(idVendor=0xd13e, custom_match=lambda d:d.serial_number==sn)
            assert self.dev, "Was not able to find USB device!"

        def read(self, idx):
            return self.dev.ctrl_transfer(bmRequestType=0xc0, bRequest=0, wValue=idx,
                                    data_or_wLength=500).tostring()

        def write(self, cmd, data):
            self.dev.ctrl_transfer(bmRequestType=0x40, bRequest=0, wValue=ord(cmd), data_or_wLength=data)

    try:
        u = dev(expect['sn'])
        assert u.dev.serial_number == expect['sn'], "Serial number mismatch"
    except AssertionError:
        fail("Could not find device over low-level SUB")

    try:
        # version 1.0.0 will fail here
        addr = B2A(u.read(3))
    except:
        if version == '1.0.0':
            print("  - old version cannot do more checks")
            return

    try:
        assert addr == expect['ad'].strip(), "Payment address mismatch"
        assert addr == expect_addr, "JSON vs address.txt mismatch"
    except AssertionError:
        fail('''\
Low level USB details do not match the values observed at the filesystem level!
''')

    print("  - read-back over USB EP0 correct")

    for i in range(5):
        msg = ''.join(random.sample(string.printable[:-6], 32))
        u.write('m', msg)

        for retry in range(1000):
            try:
                sig = B2A(b64encode(u.read(4)))
                break
            except usb.core.USBError:
                time.sleep(.010)
    
        ok = MS.verify_message(addr, sig, msg)
        if not ok:
            fail("Incorrect signature on test message!")
        else:
            print("  - (#%d) signed message ok: %s ~ %s" % (i+1, msg[0:8], msg[-8:]))
        
def main():
    path = find_root()

    print("\nOpendime USB at: " + path)
    addr = open(os.path.join(path, 'address.txt')).read().strip()
    print("\n Wallet address: " + addr, end='\n\n')

    vers = open(os.path.join(path, 'advanced', 'version.txt')).read().strip()
    dotted, details = vers.split(' ', 1)
    
    print("\nOpendime Version: " + dotted, end='\n\n')

    details = OrderedDict(p.split('=') for p in details.split(' '))

    for k in details:
        print("  %8s: %s" % (k, details[k]))

    if 'INSECURE' in details:
        print("\n==> Insecure Version -- for demo/testing purposes only <==\n")

    msg = open(os.path.join(path, 'advanced', 'verify.txt')).read().strip()

    msg, sig_addr, sig = MS.parse_signed_message(msg)

    # force newlines to what we need.
    if '\r' not in msg:
        msg = msg.replace('\n', '\r\n')

    if sig_addr != addr:
        fail('''\
verify.txt message not signed by correct address for unit.

You would be sending funds to: %s
but this devices asserts knowledge of: %s''' % (addr, sig_addr))

    # do math to verify msg
    ok = MS.verify_message(addr, sig, msg)

    if not ok:
        fail('''Invalid or incorrectly-signed advanced/verify.txt found.''')

    # check contents make sense
    if vers not in msg:
        fail("Exact version string not found in verify message")

    # TODO
    # - ask them to unplug/replug and check the message changes
    # - maybe use libusb to speak direct, OR
    # - verify serial number via OS-specific methods
    # - fetch SHA256 in checksum.txt and check it vs. version number, on website

    if 'UNSEALED' in msg:
        fail('''Unsealed already.\n
This Opendime looks legit but has been "unsealed". Anyone might have the private key and access to the funds it may contain. Remove funds (if any) immediately and do not trust as payment.''')

    lowlevel_tests(path, sig_addr, dotted)

    print("\nLooks good!\n\n" + addr)
    
if __name__ == '__main__':
    main()
