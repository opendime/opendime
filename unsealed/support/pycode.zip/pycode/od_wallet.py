#!/usr/bin/env pythonw
#
# Python 2&3 code to check balance and also spend the funds once unsealed.
#
from __future__ import print_function
try: input = raw_input
except NameError: pass
from collections import Counter
import os, sys, importlib 
import remote_pycoin
from pycoin.services.insight import InsightService
from pycoin.tx.tx_utils import create_signed_tx
from shared import BTC, find_root

psv = lambda n: importlib.import_module("pycoin.services."+n)
providers = {    # https://insight.is/
    'BitPay': InsightService('https://insight.bitpay.com'),
    'BitAccess': InsightService('https://search.bitaccess.ca'),
    'Blockchain.info': psv('blockchain_info'), 
    'BlockExplorer': psv('blockexplorer'), 
    'Blockr.io': psv('blockr_io'), 
    #'Chain.so': psv('chain_so').ChainSoProvider(),      #issues 167,170
    #'Biteasy': psv('biteasy'),                          #issue168
}

def publish_tx(tx):
    print("Publishing transaction:\n")

    for name, srv in providers.items():
        fcn = getattr(srv, 'send_tx', None)
        if not fcn: continue

        print(" %-19s " % name, end='')

        try:
            fcn(tx)
            print("Ok")
        except:
            print("Error")

def find_balance(addr, first_only=False):
    print("\nCurrent Balance\n")

    totals = {}
    utxos = {}
    counts = Counter()

    for name, srv in providers.items():
        fcn = getattr(srv, 'spendables_for_address', None)
        if not fcn: continue

        print(" %-19s " % name, end='')

        try:
            here = fcn(addr)
        except:
            print("ERROR")
            continue

        if not here:
            print("None")
            continue

        total = sum(i.coin_value for i in here)
        totals[name] = total
        utxos[name] = here
        for s in here:
            counts[(s.tx_hash, s.tx_out_index, s.script)] += 1 

        msg = BTC(total)
        if len(here) != 1:
            msg += "   (%d UTXO)" % len(here)

        #msg += '  ' + s.script.encode('hex')

        print(msg)

        if first_only: break

    if not utxos:
        print("\nSorry, no balance found yet.\n")
        return [], 0

    concur = set(counts.values())
    if len(concur) == 1:
        accepted = here
        which = 'good consensus'
    else:
        # confusion due to confirmations, etc.
        picked = sorted((t,nm) for nm,t in totals.items())[0][1]
        accepted = utxos[picked]
        total = sum(i.coin_value for i in accepted)
        which = 'CONFUSED. Using '+picked

    print("\n%-20s %s  [%s]\n" % ('', BTC(total), which))

    return accepted, total

def forward_balance(utxos, total, wif):

    print("Send entire %s balance to... (blank to quit)" % BTC(total))
    
    while 1:
        dest = input("\nBitcoin address: ").strip()
        if not dest: return
        if dest[0] in '13': break

    tx = create_signed_tx(utxos, [dest], wifs=[wif], fee='standard')

    print("Transaction hash:\n  %s\n\n%s" % (tx.id(), tx.as_hex()))

    print("\nLast chance! Type YES to send to network.\n\n  %s => %s\n" % (
                    BTC(tx.total_out()), tx.txs_out[0].bitcoin_address()))

    if input("\nOk? ").strip() != 'YES':
        print("\nAborted.")
        sys.exit(1)

    publish_tx(tx)
        
def main():
    path = find_root()

    print("\nOpendime USB at: " + path)

    addr = open(os.path.join(path, 'address.txt')).read().strip()

    print("\nWallet address: " + addr, end='\n\n')

    utxos, total = find_balance(addr)

    wif = open(os.path.join(path, 'private-key.txt')).read().strip()

    if total and wif[0] == '5':
        forward_balance(utxos, total, wif)

if __name__ == '__main__':
    main()
