# Use <https://github.com/richardkiss/pycoin> without first installing it nor by shipping it.
#
# WARNING: pypi.python.org is used to download file, but over HTTPS, and we check its hash.
#
from __future__ import print_function
import sys, tarfile, zipfile, hashlib, io, zipimport, tempfile
try:
    from urllib2 import urlopen
except ImportError:
    from urllib.request import urlopen

#URL = 'https://pypi.python.org/packages/source/p/pycoin/pycoin-0.62.tar.gz'
#EXPECT = '289b059339b07ccfdd828ead412218369730c12ba93fe50222d2707a276d2f55'
URL = 'https://github.com/opendime/pycoin/archive/anti-0.63.tar.gz'
EXPECT = '1432a2aa2d5b02c3fa8058e69b2bb53d4694f539050010dd1121ba235d2ca52f'

print("Downloading pycoin (wait)...")
tgz = urlopen(URL).read()
assert hashlib.sha256(tgz).hexdigest() == EXPECT, "File corrupt!"

tmp = tempfile.NamedTemporaryFile(suffix='.zip')
with zipfile.ZipFile(tmp.name, 'w') as zf:
    with tarfile.open(fileobj=io.BytesIO(tgz), mode='r:gz') as tf:
        for ti in tf:
            path = ti.path.split('/')
            if path[1:2] != ['pycoin']: continue
            ff = tf.extractfile(ti)
            if not ff: continue
            zf.writestr('/'.join(path[1:]), ff.read())

sys.modules['pycoin'] = zipimport.zipimporter(tmp.name).load_module('pycoin')

