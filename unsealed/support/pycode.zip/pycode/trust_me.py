#!/usr/bin/env pythonw
#
# Python 2&3 code to check we are a legit Opendime.
#
from __future__ import print_function
try: input = raw_input
except NameError: pass
import os, sys
import remote_pycoin
from pycoin.key import msg_signing as MS
from collections import OrderedDict
from shared import find_root

def fail(msg):
    print("\n" + '*'*48)
    print("FAIL FAIL FAIL -- Do Not Trust -- FAIL FAIL FAIL")
    print('*'*48 + '\n')

    print('PROBLEM: ' + msg)
    sys.exit(1)
        
def main():
    path = find_root()

    print("\nOpendime USB at: " + path)
    addr = open(os.path.join(path, 'address.txt')).read().strip()
    print("\n Wallet address: " + addr, end='\n\n')

    vers = open(os.path.join(path, 'advanced', 'version.txt')).read().strip()
    dotted, details = vers.split(' ', 1)
    
    print("\nOpendime Version: " + dotted, end='\n\n')

    details = OrderedDict(p.split('=') for p in details.split(' '))

    for k in details:
        print("  %8s: %s" % (k, details[k]))

    if 'INSECURE' in details:
        print("\n==> Insecure Version -- for demo/testing purposes only <==\n")

    msg = open(os.path.join(path, 'advanced', 'verify.txt')).read().strip()

    msg, sig_addr, sig = MS.parse_signed_message(msg)

    # force newlines to what we need.
    if '\r' not in msg:
        msg = msg.replace('\n', '\r\n')

    if sig_addr != addr:
        fail('''\
verify.txt message not signed by correct address for unit.

You would be sending funds to: %s
but this devices asserts knowledge of: %s''' % (addr, sig_addr))

    # do math to verify msg
    ok = MS.verify_message(addr, sig, msg)

    if not ok:
        fail('''Invalid or incorrectly-signed advanced/verify.txt found.''')

    # check contents make sence
    if vers not in msg:
        fail("Exact version string not found in verify message")

    # TODO
    # - ask them to unplug/replug and check the message changes
    # - maybe use libusb to speak direct, OR
    # - verify serial number via OS-specific methods
    # - fetch SHA256 in checksum.txt and check it vs. version number, on website

    if 'UNSEALED' in msg:
        fail('''Unsealed already.\n
This Opendime looks legit but has been "unsealed". Anyone might have the private key and access to the funds it may contain. Remove funds (if any) immediately and do not trust as payment.''')


    print("\nLooks good!")
    
if __name__ == '__main__':
    main()
